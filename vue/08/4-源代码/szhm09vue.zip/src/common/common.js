export default{
    apihost:'http://182.254.146.100:8899/'
}