<template>
  <div>
      。。。我是购物车。。。
  </div>
</template>
