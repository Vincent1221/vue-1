<template>
    <div class="tmpl">
        <!--1.0 购物车列表-->
        <div class="goodsListDiv">
            <div class="everyGoodsItemStyle" v-for="(item,index) in shopCartList" :key="item.id">
                <!--开关-->
                <mt-switch @change="jisuanTotalCountAndTotalPrice" v-model="switchValues[index]"></mt-switch>
                <!--图像-->
                <img :src="item.thumb_path" />
                <!--价格信息-->
                <div class="priceAndNumberInfo">
                    <h5>{{item.title}}</h5>
                    <p>
                        <span>{{item.sell_price}}</span>&nbsp;&nbsp;
                        商品数量:{{item.count}}
                    </p>
                </div>
                <!--删除按钮-->
                <mt-button @click="deleteItem(index)" type="danger" size="small">删除</mt-button>
            </div>
        </div>

        <!--2.0 总计-->
        <div class="totalStyle">
            <h6>总计(不含运费)</h6>
            <p>已经勾选商品&nbsp;<span>{{totalCount}}</span>&nbsp;件
            ,总价&nbsp;<span>{{totalPrice}}</span>&nbsp;元</p>
            <mt-button class="jiesuanStyle" size="small" type="danger">去结算</mt-button>
        </div>
    </div>
</template>

<style scoped>
    /**
        1.0 购物车商品列表样式
    */
    .goodsListDiv{
        padding: 5px;
    }

    .everyGoodsItemStyle{
        display: flex;
        height: 100px;
        border-bottom: 1px solid rgba(92,92,92,0.3);
        align-items: center;
    } 

    .everyGoodsItemStyle img{
        height: 75px;
        width: 75px;
        padding: 5px;
        border: 1px solid rgba(92,92,92,0.3);
        border-radius: 5px;
        margin-left: 8px;
    }

    .priceAndNumberInfo{
        margin-left: 8px;
        flex: 1;
    }

    h5{
        color: #0094ff;
    }

    .priceAndNumberInfo p{
        margin-top: 10px;
    }

    .priceAndNumberInfo span{
        color: red;
        font-size: 14px;
    }

    /**
        合计
    */
    .totalStyle{
        position: relative;
        margin-top: 10px;
        height: 100px;
        padding-top: 20px;
        padding-left: 15px;
        background-color: rgba(92,92,92,0.3)
    }

    h6{
        color: black;
        font-weight: bold;
        font-size: 16px;
    }

    .totalStyle p{
        margin-top: 10px;
    }

    .totalStyle span{
        font-size: 16px;
        color:red;
    }

    .jiesuanStyle{
        position: absolute;
        top: 35px;
        right: 15px;
    }
</style>


<script>
    import {getGoodsArray,deleteGoodsById} from '../common/shopCartHelper.js'

    import common from '../common/common.js'

    import { MessageBox } from 'mint-ui';

    import bus from '../common/commonvue.js'

    export default{
        data(){
            return {
                shopCartList:[],
                switchValues:[],
                totalCount : 0,
                totalPrice : 0
            }
        },
        created(){
            this.getShopCartListData()
        },
        methods:{
            //找服务器获取购物车数据
            getShopCartListData(){
                //1.把localStorage中的数组,转成对象{87:3,88:2}
                /**
                 * [{"goodsId":"87","count":1},
                 * {"goodsId":"88","count":2},
                 * {"goodsId":"87","count":2}]
                 */
                var goodsArray = getGoodsArray()

                //2.定义一个空对象
                var tempObj = {}

                for(var i=0;i<goodsArray.length;i++){
                    //判断tempObjkey是否存在
                    if(tempObj[goodsArray[i].goodsId]){
                        tempObj[goodsArray[i].goodsId]+=parseInt(goodsArray[i].count || '0')
                    }else{
                        tempObj[goodsArray[i].goodsId] = parseInt(goodsArray[i].count || '0')
                    }
                }

                //3.遍历上面的对象，获取key值，加入新的数组
                var tempArray = []
                for(var key in tempObj){
                    tempArray.push(key)
                }

                //4.调用tempArray.join(',')获取参数的字符串87,88
                var ids = tempArray.join(',') 
                
                //5.发送请求
                const url = common.apihost + "api/goods/getshopcarlist/"+ids
                this.$http.get(url).then(res=>{
                    res.body.message.forEach((item,i)=>{
                        item.count = tempObj[item.id]

                        //我给switchValues的i添加默认值
                        this.switchValues[i] = true
                    })
                    this.shopCartList = res.body.message
                    //console.log(this.shopCartList)

                    //3.统计我们的总个数和总价格
                    this.jisuanTotalCountAndTotalPrice()
                },err=>{

                })
            },
            //计算总件数和总价格
            jisuanTotalCountAndTotalPrice(){
                //1.在外面定义两个临时的变量，用来累加总个数和总价格
                var tempCount = 0;
                var tempPrice = 0;

                //巧妙的利用了switchValues数组的索引和我们的shopCartList数组是一致的
                this.switchValues.forEach((item,i)=>{
                    if(item==true){//打开
                        //累加我们的数量和价格
                        var tempShopCart = this.shopCartList[i]

                        tempCount+=tempShopCart.count

                        tempPrice+=(tempShopCart.count * tempShopCart.sell_price)
                    }
                })

                this.totalCount = tempCount
                this.totalPrice = tempPrice
            },
            deleteItem(index){
                MessageBox.confirm('确定删除该商品吗?').then(action => {
                    //1.更改徽标的值
                    bus.$emit('updateBadge',-this.shopCartList[index].count)
                    
                    //2.删除localStorage中对应id的值
                    deleteGoodsById(this.shopCartList[index].id)

                    //3.根据索引值，删除shopCartList和switchValues中的对应索引的值
                    this.shopCartList.splice(index,1)
                    this.switchValues.splice(index,1)

                    //4.调用计算总个数与价格的方法
                    this.jisuanTotalCountAndTotalPrice()
                },cancel=>{
                    console.log(cancel)
                });
            }
        }
    }
</script>