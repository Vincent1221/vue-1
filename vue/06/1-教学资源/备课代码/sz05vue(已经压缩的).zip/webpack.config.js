//导入path 
var path = require('path')

//导入那个自动生成index.html，并且导入bundle.js
var HtmlWebpackPlugin = require('html-webpack-plugin')

var webpack = require('webpack')

module.exports = {
  entry:'./src/main.js', //打包的入口文件
  output:{ //打包之后的输出文件
    path: path.join(__dirname,'dist'),
    filename: 'bundle.js'
  },
  module: {
        loaders: [ //1.x的兼容写法，最好用rules
            {
                test: /\.vue$/,
                loader: 'vue-loader'
            },
            {
                test: /\.css$/,
                loader: 'style-loader!css-loader'
            },
            {
                test: /\.(ttf|png|svg|gif)$/,
                loader: 'url-loader'
            },
            {
                test: /\.js$/,
                loader: 'babel-loader',
                exclude: /node_modules/
            },
            {
                test: /vue-preview.src.*?js$/,
                loader: 'babel-loader'
            }
        ]
  } ,
  plugins: [
    new HtmlWebpackPlugin({
        filename : 'index.html', //最终在内存中生成的文件名称，并且这个文件会在浏览器中自动打开
        template : 'template.html' //生成index.html的参照模版
    }),
    //将当前vue项目的环境设置为生产环境
    new webpack.DefinePlugin({
      'process.env': {
        NODE_ENV: '"production"'
      }
    }),
    //压缩项目中的js
    new webpack.optimize.UglifyJsPlugin({
      sourceMap: true,
      compress: {
        warnings: false //去除警告信息
      },
      comments: false //去掉版权信息等注释
    }),
    // 代码顺序优化
    new webpack.optimize.OccurrenceOrderPlugin()
  ]
}