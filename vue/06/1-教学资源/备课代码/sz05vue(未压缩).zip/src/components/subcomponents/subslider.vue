<template>
    <div>
        <!--1.0 轮播-->
        <mt-swipe class="swipeBox" :auto="2000">
            <mt-swipe-item v-for="item in lunboArray" :key="item.url">
                <a :href="item.url">
                    <img :src="item.img">
                </a>
            </mt-swipe-item>
        </mt-swipe>
    </div>
</template>

<style>
    /*轮播图的样式*/
    .swipeBox {
        height: 250px;
        width: 100%;
    }

    img {
        height: 250px;
        width: 100%;
    }

</style>


<script>
    import common from '../common/common.js'

    export default {
        data(){
            return {
                lunboArray:[]
            }
        },
        created(){
            this.getlunboData()
        },
        methods:{
            getlunboData(){
                const url =common.apihost + this.lunbo_url

                this.$http.get(url).then(res=>{
                    this.lunboArray = res.body.message
                },err=>{

                })
            }
        },
        props:['lunbo_url']
    }
</script>
