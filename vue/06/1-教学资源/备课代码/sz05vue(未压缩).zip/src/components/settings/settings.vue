<template>
    <div class="tmpl">
        我是设置
    </div>
</template>

<script>
    export default{
        created(){
            // this.$axios.get('http://webhm.top:8899/api/getlunbo').then(response=>{
            //     console.log(response.data)
            // })
        }
    }
</script>

