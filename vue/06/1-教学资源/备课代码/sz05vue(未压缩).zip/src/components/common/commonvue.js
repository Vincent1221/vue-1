import Vue from 'vue'

//在commonvue.js中创建了一个空的Vue实例，并且导出
export default new Vue()

// var bus = new Vue()

// module.exports = bus