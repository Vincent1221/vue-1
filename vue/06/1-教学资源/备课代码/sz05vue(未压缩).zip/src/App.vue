<template>
    <!--必须要有唯一的根元素-->
    <div>
        <!--顶部 mint-ui -->
        <mt-header fixed title="Vue项目"></mt-header>

		<!--全局返回按钮-->
		<div v-show="isShow" @click="goBack" class="goBackStyle">&lt;返回</div>

        <!--中间的路由占位符-->
        <router-view></router-view>

        <!--底部的TabBar-->
        <nav class="mui-bar mui-bar-tab">
			<router-link to="/home" class="mui-tab-item">
				<span class="mui-icon mui-icon-home"></span>
				<span class="mui-tab-label">首页</span>
			</router-link>
			<router-link to="/message" class="mui-tab-item">
				<span class="mui-icon mui-icon-email"></span>
				<span class="mui-tab-label">消息</span>
			</router-link>
			<router-link to="/shopcart" class="mui-tab-item">
				<span class="mui-icon mui-icon-contact"><span id="badgeId" class="mui-badge">{{count}}</span></span>
				<span class="mui-tab-label">通讯录</span>
			</router-link>
			<router-link to="/settings" class="mui-tab-item">
				<span class="mui-icon mui-icon-gear"></span>
				<span class="mui-tab-label">设置</span>
			</router-link>
		</nav>
    </div>
</template>

<style>
    /* 更改mint-ui的样式 */
    /*.mint-header {
        background-color: green;
    }*/

	.goBackStyle{
		position: fixed;
		left:10px;
		top:10px;
		z-index: 1;
		color: white;
		font-size: 14px;
		font-weight: 700;
	}
</style>

<script>
	import bus from './components/common/commonvue.js'

	import $ from 'jquery'

	//按需导入
	import {getGoodsTotalCount} from './components/common/shopCartHelper.js'

	bus.$on("updateBadge",function(badgeCount){
		//更改徽标的值
		//1.获取旧的值
		var oldCount = $("#badgeId").text()

		//2.旧的值加上新的值
		var newCount = parseInt(oldCount) + badgeCount

		//3.将最后的结果添加回去
		$("#badgeId").text(newCount)
	})

	export default{
		data(){
			return {
				count : 0,
				isShow:false
			}
		},
		created(){
			this.count = getGoodsTotalCount()
		},
		methods:{
			goBack(){
				this.$router.go(-1)
			},
			load(){
				this.showOrHidden(this.$route.path)
			},
			showOrHidden(path){
				if(path=='/home' || path=='/message'
				|| path=='/shopcart' || path=='/settings'){
					this.isShow=false
				}else{
					this.isShow=true
				}
			}
		},
		watch:{ //除了data()中的模型数据能监控之外，还能监控Vue实例的属性
			'$route':function(newValue,oldValue){
				this.showOrHidden(newValue.path)
			}
		},
		mounted() {
      		window.addEventListener('load', this.load)
    	}
	}
</script>