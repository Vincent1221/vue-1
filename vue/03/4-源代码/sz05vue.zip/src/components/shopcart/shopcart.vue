<template>
    <div class="tmpl">我是购物车</div>
</template>
