<template>
    <div class="tmpl">
        我是设置
    </div>
</template>

